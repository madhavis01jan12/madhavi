class RobotHeart:
    def __init__(self):
        self.data = []